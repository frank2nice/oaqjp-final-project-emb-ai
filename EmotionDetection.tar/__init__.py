"""
EmotionDetection Package for detecting emotions in text using IBM Watson NLP
"""

from .emotion_detection import emotion_detector

__all__ = ['emotion_detector']

